/* ==========================================================================
   HISTORY — renderHistory, history entry deletion
   ========================================================================== */

const _trashSVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 640 640" fill="currentColor"><path d="M232.7 69.9C237.1 56.8 249.3 48 263.1 48L377 48C390.8 48 403 56.8 407.4 69.9L416 96L512 96C529.7 96 544 110.3 544 128C544 145.7 529.7 160 512 160L128 160C110.3 160 96 145.7 96 128C96 110.3 110.3 96 128 96L224 96L232.7 69.9zM128 208L512 208L512 512C512 547.3 483.3 576 448 576L192 576C156.7 576 128 547.3 128 512L128 208zM216 272C202.7 272 192 282.7 192 296L192 488C192 501.3 202.7 512 216 512C229.3 512 240 501.3 240 488L240 296C240 282.7 229.3 272 216 272zM320 272C306.7 272 296 282.7 296 296L296 488C296 501.3 306.7 512 320 512C333.3 512 344 501.3 344 488L344 296C344 282.7 333.3 272 320 272zM424 272C410.7 272 400 282.7 400 296L400 488C400 501.3 410.7 512 424 512C437.3 512 448 501.3 448 488L448 296C448 282.7 437.3 272 424 272z"/></svg>`;

async function renderHistory() {
  const historyList = document.getElementById('historyList');
  const result = await storageGet(['history']);
  const history = result.history || [];
  historyList.innerHTML = '';

  if (history.length === 0) {
    historyList.innerHTML = '<p class="no-history">No history yet</p>';
    return;
  }

  [...history].reverse().forEach(entry => {
    const item = document.createElement('div');
    item.className = 'history-item';

    // Header row
    const header = document.createElement('div');
    header.className = 'history-header';

    const dateEl = document.createElement('span');
    dateEl.className = 'history-date';
    const d = new Date(entry.date + 'T00:00:00');
    dateEl.textContent = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

    const pct = document.createElement('span');
    pct.className = 'history-pct' + (entry.percentage === 100 ? ' perfect' : '');
    pct.textContent = entry.percentage + '%';

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'history-delete-btn';
    deleteBtn.innerHTML = _trashSVG;

    deleteBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const result = await storageGet(['history']);
      const updated = (result.history || []).filter(h => h.date !== entry.date);
      await storageSet({ history: updated });
      renderHistory();
    });

    header.appendChild(dateEl);
    header.appendChild(pct);
    header.appendChild(deleteBtn);
    item.appendChild(header);

    // Accordion task list — toggled via .open class + max-height in CSS
    const taskMenu = document.createElement('div');
    taskMenu.className = 'history-tasks';

    entry.tasks.forEach(t => {
      const row = document.createElement('div');
      row.className = 'history-task-row' + (t.done ? ' done' : '');
      row.textContent = (t.done ? '✓ ' : '✗ ') + t.text;
      taskMenu.appendChild(row);
    });

    item.appendChild(taskMenu);

    header.addEventListener('click', () => {
      item.classList.toggle('open');
    });

    historyList.appendChild(item);
  });
}
